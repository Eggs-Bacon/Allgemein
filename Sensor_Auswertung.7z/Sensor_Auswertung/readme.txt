sensor_ruhe: Sensor liegt auf ebener fläche (vlg. Bild sensor_ruhe)

sensor_anwinkeln: zunächst ruhe (sensor liegt auf fläche)-> langsam anwinkeln -> kurz position (rechter winkel) halten -> wieder absenken -> kurz ruhe -> wiederholen
vgl. Video sensor_anwinkeln

sensor_RLrotation: zunächst ruhe (sensor liegt auf fläche) -> langsame rechtsrotation -> kurz halten -> langsam zurück -> kurz ruhe -> langsame linksrotation -> kurz halten -> langsam zurück -> wiederholen
vgl. video sensor_RLrotation

sensor_beugen: zunächst ruhe (sensor liegt auf fläche) -> langsam beugen (180 grad bewegung -> sensor ist dann quasi kopfüber) -> kurz halten -> langsam zurück -> kurz halten -> wiederholen
vgl. video sensor_beugen


Baud rate: 9600
